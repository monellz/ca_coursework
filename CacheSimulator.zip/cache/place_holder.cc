#include "include/replace_policy.h"
#include "include/way_metadata.h"
#include "include/cache.h"


/*
 *
 * all the code is in the headers (due to the limitation of template)
 *
 *
 */


#include "perf_stats.h"

PerfStats PerfStats::instance;
