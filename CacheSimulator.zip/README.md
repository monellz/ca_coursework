# Cache Simulator

### 依赖

* openmp
* gtest

### 使用方式

```bash
mkdir build
cd build
cmake ..
make

#或者
bash build.sh
```

```cache```与```file_parser```会被编译成静态库

